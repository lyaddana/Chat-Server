

import socket
import threading

server=socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(('127.0.0.1',8080))
server.listen()

clients=[]
nicknames=[]
msg=[]
parts=[]
def broadcast(message):
    for client in clients:
        client.send(message)

def handle(client):
    while True:
        try:
            message = client.recv(1024).decode('ascii')
            index = clients.index(client)
            n = nicknames[index]
            msg=message.split(":")
            if " /bc" in msg[1]:
                broadcast(msg[1][5:].replace('"', "").encode('ascii'))
            elif(msg[1]==' /help'):
                str='/bc :    Broadcasts message given in quotes to all the connected clients.'+'\n'+'/users : Requests a list of users from the server and print them .'+'\n'+'/dm :    Sends given message in quotes to individual client \n'+'/quit :  Disconnect form the server\n'+'/help :  display a list of all commands and their inputs/behaviors\n'
                client.send(str.encode('ascii'))
            elif(msg[1]==' /users'):
                for nickname in nicknames:
                    client.send('{}\n'.format(nickname).encode('ascii')) 
            elif " /dm" in msg[1]:
                i=msg[1].find('"')
                index=-2
                message=msg[1][i+1:len(msg[1])-1]
                parts=msg[1].split(" ")
                if(parts[2] in nicknames):
                    index=nicknames.index(parts[2])
                    client=clients[index]
                    m = '{}: {}'.format(n, message)
                    client.send(m.encode('ascii'))
                else:
                    str=" Worng client name entered!"
                    client.send(str.encode('ascii')) 
            elif " /quit" in msg[1]:
                i=msg[1].find('"')
                index = clients.index(client)
                clients.remove(client)
                client.close()
                nickname = nicknames[index]
                print(nickname)
                if(i==-1):
                    broadcast('{} has lost its connection!'.format(nickname).encode('ascii'))
                else:
                    broadcast('{} left!'.format(nickname).encode('ascii'))
                nicknames.remove(nickname)
                
                


        except:
            # Removing And Closing Clients
            index = clients.index(client)
            clients.remove(client)
            client.close()
            nickname = nicknames[index]
            broadcast('{} left!'.format(nickname).encode('ascii'))
            nicknames.remove(nickname)
            break



def receive():
    while True:
        # Accept Connection
        client, address = server.accept()
        print("Connected with {}".format(str(address)))

        # Request And Store Nickname
        client.send('NICK'.encode('ascii'))
        nickname = client.recv(1024).decode('ascii')
        nicknames.append(nickname)
        clients.append(client)

        # Print And Broadcast Nickname
        print("Nickname is {}".format(nickname))
        broadcast("{} joined!".format(nickname).encode('ascii'))
        client.send('Connected to server!'.encode('ascii'))

        # Start Handling Thread For Client
        thread = threading.Thread(target=handle, args=(client,))
        thread.start()



print("Server is listening")
receive()
